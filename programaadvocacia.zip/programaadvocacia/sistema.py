# coding: utf - 8
# Programa produzido por Caio Simplício, aluno da graduação em Ciência da Computação pela UFCG
# Julho 2015
# Verificação de contas

import sqlite3
import time
import datetime

# Conexão com o Banco de Dados
connection = sqlite3.connect('contas.db')
c = connection.cursor()

# Função de criar tabelas
def create_table():
	c.execute('CREATE TABLE IF NOT EXISTS pessoa (nome text, valordevido real, data text, parcelas integer, loja text)')
	c.execute('CREATE TABLE IF NOT EXISTS pre_cadastro (nome text, valordevido real, endereco text, loja text)')
	c.execute('CREATE TABLE IF NOT EXISTS pago (nome text, numero int)')
	
create_table()
percento = "%"
# Função de pesquisa
def leitura_de_dados_e_retorna_linhas0134(palavra):
	for linha in c.execute(sql,(palavra,)):
		print "Nome: %s" % linha[0]
		print "Valor devido: %.2f" % linha[1]
		print "Deve a loja: %s" % linha[4] 
		print "O valor deve ser pago com %d parcelas." % linha[3]

# Função pesquisa pré
def leitura_precadastro(palavra):
	for linha in c.execute(sql,(palavra,)):
		print "Nome: %s" % linha[0]
		print "Valor devido: %.2f" % linha[1]
		print "Mora em: %s" % linha[2]
		print "Deve a loja: %s" % linha[3] 
		
# Função de atualização do pagamento
def atualizacao_do_pagamento(palavra):
	for linha in c.execute(sql,(palavra,)):
		return linha[1]
		
# Função para atualizar parcelas
def atualizacao_das_parcelas(palavra):
	for linha in c.execute(sql,(palavra,)):
		return linha[3]		

# Função para alterar de devedor para pago
def alterar_para_pago(palavra, valor):
	for linha in c.execute(sql,(palavra,)):
		if (linha[1] - valor) <= 0:
			c.execute('INSERT INTO pago (nome, numero) VALUES (?,?)' , (palavra, valor))
			connection.commit()
			print "O cliente quitou sua dívida, então foi movido para a área de pagos."
			
# Começo do programa

print "*************************************************"
print "**BEM VINDOS AO SISTEMA DE CADASTRO DE CLIENTES**"
print "*************************************************"
print ''
print "Sistema inteiramente desenvolvido por Caio Simplício"
print ''
print "Para consultar os comandos disponíveis, digite: 'Ajuda'"
print ''

while True:
	funcao = raw_input("Digite qual função desejada? ")
	
	# Sair do programa
	if funcao.upper() == "SAIR" or funcao.upper() == "EXIT": break
	
	# Função de pré-cadastro
	elif funcao.upper() == "PRÉ-CADASTRO" or funcao.upper() == "PRÉ CADASTRO" or funcao.upper() == "PRE CADASTRO" or funcao.upper() == "PRE-CADASTRO":
		print ""
		print "A função Pré-Cadastro possui outras subfunções, para saber quais são, digite 'AJUDA'."
		print ""
		while True:
			funcao_precadastro = raw_input("Digite a função desejada no Pré Cadastro: ")
			if funcao_precadastro.upper() == "SAIR": break
			
			# Cadastrar no banco de dados
			elif funcao_precadastro.upper() == "CADASTRAR":
				print ""
				nome_do_cliente = raw_input("Digite o nome do cliente a ser pré-cadastrado: ")
				valor_devido = float(raw_input("Digite o valor que o cliente deve: "))
				endereco_cliente = raw_input("Digite de forma compreensível o endereço do cliente: ")
				loja_devida = raw_input("Digite a loja a qual o cliente é devedor: ")
				c.execute('INSERT INTO pre_cadastro (nome, valordevido, endereco, loja) VALUES (?,?,?,?)' , (nome_do_cliente.upper(), valor_devido, endereco_cliente.upper(), loja_devida.upper()))
				connection.commit()
				print ""
				print "Cliente cadastrado com sucesso!"
				print ""
				
			# Pesquisa no Pré Cadastro
			elif funcao_precadastro.upper() == "PESQUISAR":
				print ""
				nome_do_cliente = raw_input("Digite o nome do cliente a ser pesquisado no banco de dados do pré-cadastro: ")
				sql = 'SELECT * FROM pre_cadastro WHERE nome = ?'
				leitura_precadastro(nome_do_cliente.upper())
				print ""
				
			elif funcao_precadastro.upper() == "AJUDA":
				print ""
				print "(Cadastrar) ==> Cadastra um novo cliente no banco de pré cadastro."
				print "(Pesquisar) ==> Pesquisa no banco de dados, um cliente pelo nome, e retorna seus dados cadastrados."
				print "(Sair) ==> Sai da função 'Pré-Cadastro'"
				
			else:
				print "Comando inválido, tente novamente!"
		
	# Pesquisa no banco de dados
	elif funcao.upper() == "PESQUISAR CLIENTE" or funcao.upper() == "CLIENT SEARCH":
		try:
			print ""
			cliente_nome = raw_input("Digite o nome do cliente a ser pesquisado: ")
			print ""
			sql = 'SELECT * FROM pessoa WHERE nome = ?'
			leitura_de_dados_e_retorna_linhas0134(cliente_nome.upper())
			print ""
		except Exception: 
			print "Falha na pesquisa do nome, tente realizar novamente!"
			print ""
			pass
	
	# Faz uma consulta rápida de números de parcelas do cliente devedor
	elif funcao.upper() == "CONSULTA SIMPLES" or funcao.upper() == "SIMPLE QUERY":
		print ""
		nome_cliente = raw_input("Digite o nome do cliente devedor: ")
		valor_devido = float(raw_input("Digite agora o valor devido: "))
		parcelas = int(raw_input("Digite o valor de parcelas máximas a serem cobradas: "))
		print ""
		print "************************"
		print ""
		print "%s, poderá dividir sua dívida com os valores a seguir:" % nome_cliente
		print ""
		for vezes in xrange(1, parcelas):
			print "%d X de %.2f" % (vezes+1, float(valor_devido)/(vezes+1))
		print ""
		print "O Pagamento da dívida à vista, há um desconto de 20%s, ou seja, você À VISTA, pagará %.2f." % (percento, (valor_devido*0.8))
		print ""
		print "************************"
		print ""

	# Cadastro de novos devedores.
	elif funcao.upper() == "NOVO CLIENTE" or funcao.upper() == "CADASTRAR CLIENTE":
		print ""
		nome_do_cliente = raw_input("Digite o nome completo do cliente a ser cadastrado: ")
		valor_a_ser_quitado = float(raw_input("Digite o valor devido do cliente acima: "))
		parcelas_acertadas = int(raw_input("Digite o número de parcelas acertadas com o cliente: "))
		data = str(datetime.datetime.fromtimestamp(int(time.time())).strftime('%Y-%m-%d %H:%M:%S'))
		loja_cadastrada = raw_input("Digite o nome da loja a ser cadastrada: ")
		# Atualizando os dados da table
		c.execute('INSERT INTO pessoa (nome, valordevido, data, parcelas, loja) VALUES (?,?,?,?,?)' , (nome_do_cliente.upper(), valor_a_ser_quitado, data, parcelas_acertadas, loja_cadastrada.upper()))
		connection.commit()		
		print "O cliente %s, foi cadastrado com sucesso!" % nome_do_cliente
		print ""
		
	# Comando de Atualizar registro
	elif funcao.upper() == "ATUALIZAR REGISTRO" or funcao.upper() == "PAGAMENTO":
		print ""
		nome_a_ser_pesquisado = raw_input("Digite o nome do cliente a ser pesquisado: ")
		valor_pago = float(raw_input("Digite o valor da parcela a ser descontada do valor total devido: "))
		sql = 'SELECT * FROM pessoa WHERE nome = ?'
		c.execute(""" UPDATE pessoa SET valordevido = ?, parcelas = ? WHERE nome = ? """, ((atualizacao_do_pagamento(nome_a_ser_pesquisado.upper())- valor_pago) ,(atualizacao_das_parcelas(nome_a_ser_pesquisado.upper())-1), nome_a_ser_pesquisado.upper()))
		connection.commit()
		print "Alteração no pagamento realizada com sucesso!"
		print "Alteração no número de parcelas realizada com sucesso!"
		print ""
		alterar_para_pago(nome_a_ser_pesquisado.upper(), valor_pago)
		print ""
		
	# Comando de ajuda, lista todos os comandos já disponíveis
	elif funcao.upper() == "AJUDA" or funcao.upper() == "HELP":
		print ""
		print "************************"
		print "Os comandos abaixo, são comandos já listados:"
		print "(Pré Cadastro) ==> Abre uma nova linha de comandos relativos ao pré cadastro e a pesquisa de cliente pré cadastrados."
		print "(Pagamento) ==> Faz uma busca rápida no banco de dados com o nome do cliente já cadastrado, e em seguida reduz o valor especificado do valor total devido e também reduz uma parcela do número total de parcelas combinadas."
		print "(Pesquisar Cliente) ==> Faz uma busca em todo o banco de dados disponível em busca de um cliente especificado." 
		print "(Consulta Simples) ==> Faz uma consulta do valor em parcelas do cliente, NÃO CADASTRANDO-O NO SISTEMA."
		print "(Novo Cliente) ==> Adiciona/Cadastra um novo cliente devedor ao banco de dados."
		print "(Sair) ==> Desliga o Programa."
		print "************************"
		print ""
		
	# Comando para função indisponível.
	else:
		print ""
		print "Função não disponível. Tente novamente!"
		print ""
